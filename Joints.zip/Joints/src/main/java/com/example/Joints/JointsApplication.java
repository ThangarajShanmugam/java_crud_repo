package com.example.Joints;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JointsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JointsApplication.class, args);
	}

}
